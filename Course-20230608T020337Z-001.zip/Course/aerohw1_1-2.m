clear all; clc;

% Zero Initial Conditions
x0=[0;0];
% Simulation time tfinal in secs
tfinal=10;
% Taking T=h
h=0.01;
% Sampling time
T=h;
% Initial control input
u=0;
% Start Time
t0=0;
% Gain
K=1;
ym=1;
% Step Input
%input = frest.createStep('Ts',0.01);
% Plant model
P=tf([1],[1,1,0]);
% State-space model
S = ss(P);
% Discretizing the continuous-time system using ZOH
disc=c2d(ss(P),T);
Phi=disc.a;%Phi(h)
Gamma=disc.b;%Gamma(h)
C1=disc.c;
D1=disc.d;
nframes=tfinal/h;
% Initial control input
u0=K*(ym-x0(2));
y0=C1*x0+D1*u0;
%Initialising the state for the
xk=[0;0];
xk1=[0;0];
count=0;
for i=1:nframes
    xk(:,i)=xk1;
    for count=0:0.01:1
        uk=(ym-K*xk(2,i));
    end
    xk1=Phi*xk(:,i)+Gamma*uk;
    yk=[y;C1*xk(:,i)+D1*uk];
    t=[t;i*h]
end

plot(xk(2,:));