clear all; clc;

% Zero Initial Conditions
x0=[0;0];
% Simulation time tfinal in secs
tfinal=10;
% Taking T=h
h=1;
% Sampling time
T=h;
% Initial control input
u=0;
% Start Time
t0=0;
% Gain
K=1;
ym=1;
% Step Input
%input = frest.createStep('Ts',0.01);
% Plant model
P=tf([1],[1,1,0]);
% State-space model
S = ss(P);
% Discretizing the continuous-time system using ZOH
disc=c2d(ss(P),T);
Phi=disc.a;%Phi(h)
Gamma=disc.b;%Gamma(h)
C1=disc.c;
D1=disc.d;
nframes=tfinal/h +1;
% Initial control input
u0=K*(ym-x0(2));
y0=C1*x0+D1*u0;
%Initialising the state for the
xk=x0';
xk1=xk;
t=[0:h:tfinal];
u=[u0];
for i=1:nframes
    if(mod(t(i),T)==0)
        uk=K*(ym-xk);
    end
    u=[u;uk]
    xk1=Phi*xk+Gamma*uk;
    yk=[yk;C1*xk+D1*uk];
end
figure(2);
subplot(2,1,1);
plot(t, yk);


subplot(2,1,2)
plot(t, u_store);